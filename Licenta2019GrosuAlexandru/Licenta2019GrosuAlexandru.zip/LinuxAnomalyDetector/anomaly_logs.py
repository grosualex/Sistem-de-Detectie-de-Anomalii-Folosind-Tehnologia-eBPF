import os
import time

while True:
    os.system("cat logs/anomaly_logs/*")
    time.sleep(1)
